# 基于大数据技术的餐厅经营分析系统

## 项目简介

本项目是一个基于Hadoop生态系统的餐厅经营分析系统，实现了数据采集、存储、清洗、分析和查询的完整流程。

## 技术栈

- **HDFS**: 分布式文件存储
- **MapReduce**: 数据清洗
- **HBase**: 实时查询
- **Hive**: 数据仓库和分析

## 项目结构

```
.
├── data/                          # 测试数据
│   ├── order_log_20231201.txt    # 订单日志1
│   ├── order_log_20231202.txt    # 订单日志2
│   ├── order_log_20231203.txt    # 订单日志3
│   ├── user_profiles.csv         # 用户信息
│   └── dishes.csv                # 菜品信息
├── mapreduce/                     # MapReduce程序
│   ├── pom.xml                   # Maven配置
│   └── src/main/java/com/restaurant/
│       └── OrderDataCleaner.java # 数据清洗程序
├── scripts/                       # 脚本文件
│   ├── hdfs_setup.sh             # HDFS数据上传
│   ├── hdfs_query.sh             # HDFS查询
│   ├── run_mapreduce.sh          # 运行MapReduce
│   ├── hbase_setup.sh            # HBase表创建
│   ├── hbase_import.sh           # HBase数据导入
│   ├── hbase_query.sh            # HBase查询
│   ├── hive_setup.sql            # Hive表创建
│   ├── hive_analysis.sql         # Hive数据分析
│   └── run_hive.sh               # 运行Hive
├── 设计报告.md                    # 详细设计报告
├── 要求.txt                       # 项目要求
└── README.md                      # 本文件
```

## 快速开始

### 前置要求

- Hadoop 3.x
- HBase 2.x
- Hive 3.x
- Java 8+
- Maven 3.x

### 运行步骤

#### 1. 上传数据到HDFS

```bash
cd scripts
chmod +x hdfs_setup.sh
./hdfs_setup.sh
```

#### 2. 运行MapReduce数据清洗

```bash
chmod +x run_mapreduce.sh
./run_mapreduce.sh
```

#### 3. 创建和查询HBase表

```bash
# 创建表
chmod +x hbase_setup.sh
./hbase_setup.sh

# 导入数据
chmod +x hbase_import.sh
./hbase_import.sh

# 查询数据
chmod +x hbase_query.sh
./hbase_query.sh
```

#### 4. 运行Hive分析

```bash
chmod +x run_hive.sh
./run_hive.sh
```

## 核心功能

### 1. 数据存储（HDFS）

- 按日期分文件存储订单日志
- 集中存储用户和菜品信息
- 支持大规模数据存储

### 2. 数据清洗（MapReduce）

- 过滤无效记录
- 解析结构化字段
- 数据格式转换

### 3. 实时查询（HBase）

- 查询用户近期订单
- 支持时间范围查询
- 毫秒级响应

### 4. 数据分析（Hive）

- 销量排行榜
- VIP客户发现
- 菜品关联分析
- 门店营业额对比
- 销售趋势分析

## 数据说明

### 订单日志格式

```
订单ID|用户ID|门店ID|菜品列表|订单时间|金额
O001|U001|S001|D001,D005|2023-12-01 08:15:23|58.50
```

### 用户信息格式

```csv
user_id,age_group,gender,preference_taste,member_level,registration_date
U001,25-30,M,辣味,Gold,2022-05-15
```

### 菜品信息格式

```csv
dish_id,dish_name,category,price,taste_type,is_recommended
D001,宫保鸡丁,川菜,28.00,辣味,1
```

## HBase表设计

### 表名
`customer_orders`

### RowKey设计
`userId_timestamp` (例如: U001_20231201081523)

### 列族
- `order_info`: 订单基本信息
- `dish_info`: 菜品信息
- `user_info`: 用户信息

## Hive表设计

### 数据库
`restaurant_db`

### 表
1. `orders_cleaned`: 清洗后的订单数据
2. `user_profiles`: 用户信息
3. `dishes`: 菜品信息

## 常见问题

### Q1: HDFS上传失败？
A: 检查Hadoop是否正常运行，确认有足够的存储空间

### Q2: MapReduce任务失败？
A: 检查输入路径是否正确，输出路径是否已存在（需要删除）

### Q3: HBase连接失败？
A: 确认HBase服务是否启动，检查ZooKeeper状态

### Q4: Hive查询慢？
A: 考虑使用分区表，或者使用ORC/Parquet格式存储

## 作者信息

- **项目名称**: 基于大数据技术的餐厅经营分析系统
- **开发时间**: 2023年12月
- **技术支持**: Hadoop生态系统

## 许可证

本项目仅用于学习和研究目的。

