#!/bin/bash

# 重新创建 Hadoop 和 ZooKeeper 目录

mkdir -p /tmp/hadoop/namenode
mkdir -p /tmp/hadoop/datanode
mkdir -p /tmp/zookeeper

chmod -R 755 /tmp/hadoop
chmod -R 755 /tmp/zookeeper

echo "✓ 目录已创建"

# 重新格式化 HDFS
echo "重新格式化 HDFS..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs namenode -format -force

echo "✓ HDFS 已格式化"

