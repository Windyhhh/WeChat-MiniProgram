#!/bin/bash

source ~/.bashrc_bigdata

echo "=== 创建 HDFS 目录 ==="
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/bigdata/input/logs
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/bigdata/input/profiles
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/bigdata/input/dishes
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/bigdata/output
echo "✓ 目录已创建"
echo ""

echo "=== 上传数据文件 ==="
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -put -f /mnt/c/Users/32517/Desktop/150/data/order_log_*.txt /user/bigdata/input/logs/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -put -f /mnt/c/Users/32517/Desktop/150/data/user_profiles.csv /user/bigdata/input/profiles/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -put -f /mnt/c/Users/32517/Desktop/150/data/dishes.csv /user/bigdata/input/dishes/
echo "✓ 数据已上传"
echo ""

echo "=== 验证上传 ==="
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -ls -R /user/bigdata/input/

