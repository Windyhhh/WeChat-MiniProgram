#!/bin/bash

# 添加 Hadoop 用户环境变量

HADOOP_ENV="/opt/bigdata/hadoop-3.3.6/etc/hadoop/hadoop-env.sh"

echo "添加 Hadoop 用户变量..."

cat >> $HADOOP_ENV << 'EOF'

# Hadoop 用户配置
export HDFS_NAMENODE_USER=root
export HDFS_DATANODE_USER=root
export HDFS_SECONDARYNAMENODE_USER=root
export YARN_RESOURCEMANAGER_USER=root
export YARN_NODEMANAGER_USER=root
EOF

echo "✓ Hadoop 用户变量已添加"

