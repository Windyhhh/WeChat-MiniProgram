# Docker 方案 - Hadoop 大数据环境快速部署

如果WSL安装遇到问题，可以使用Docker快速部署。

## 前置条件

- Docker Desktop 已安装
- Docker 可以正常运行

## 方案1: 使用现成的 Docker 镜像

### 步骤1: 拉取镜像

```bash
# 拉取包含 Hadoop、HBase、Hive 的镜像
docker pull bde2020/hadoop-namenode:2.0.0-hadoop3.3.6-java8
docker pull bde2020/hadoop-datanode:2.0.0-hadoop3.3.6-java8
docker pull bde2020/hbase-master:latest
docker pull bde2020/hbase-regionserver:latest
```

### 步骤2: 创建 Docker Compose 文件

创建 `docker-compose.yml`:

```yaml
version: '3.8'

services:
  namenode:
    image: bde2020/hadoop-namenode:2.0.0-hadoop3.3.6-java8
    container_name: namenode
    ports:
      - "9870:9870"
      - "9000:9000"
    environment:
      CLUSTER_NAME: hadoop
    volumes:
      - namenode:/hadoop/dfs/name
    networks:
      - hadoop

  datanode:
    image: bde2020/hadoop-datanode:2.0.0-hadoop3.3.6-java8
    container_name: datanode
    ports:
      - "9864:9864"
    environment:
      SERVICE_PRECONDITION: "namenode:9870"
    volumes:
      - datanode:/hadoop/dfs/data
    networks:
      - hadoop
    depends_on:
      - namenode

  hbase:
    image: bde2020/hbase-master:latest
    container_name: hbase
    ports:
      - "16010:16010"
      - "16000:16000"
    environment:
      SERVICE_PRECONDITION: "namenode:9870"
    networks:
      - hadoop
    depends_on:
      - namenode

volumes:
  namenode:
  datanode:

networks:
  hadoop:
    driver: bridge
```

### 步骤3: 启动容器

```bash
# 启动所有服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

### 步骤4: 访问服务

- HDFS NameNode: http://localhost:9870
- HBase Master: http://localhost:16010

---

## 方案2: 自定义 Dockerfile

创建 `Dockerfile`:

```dockerfile
FROM ubuntu:20.04

# 安装基础工具
RUN apt-get update && apt-get install -y \
    openjdk-8-jdk \
    wget \
    curl \
    openssh-server \
    openssh-client \
    && rm -rf /var/lib/apt/lists/*

# 设置 Java 环境
ENV JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
ENV PATH=$JAVA_HOME/bin:$PATH

# 创建安装目录
RUN mkdir -p /opt/bigdata

# 下载和安装 Hadoop
RUN cd /opt/bigdata && \
    wget -q https://archive.apache.org/dist/hadoop/common/hadoop-3.3.6/hadoop-3.3.6.tar.gz && \
    tar -xzf hadoop-3.3.6.tar.gz && \
    rm hadoop-3.3.6.tar.gz

# 下载和安装 HBase
RUN cd /opt/bigdata && \
    wget -q https://archive.apache.org/dist/hbase/2.5.5/hbase-2.5.5-bin.tar.gz && \
    tar -xzf hbase-2.5.5-bin.tar.gz && \
    rm hbase-2.5.5-bin.tar.gz

# 下载和安装 Hive
RUN cd /opt/bigdata && \
    wget -q https://archive.apache.org/dist/hive/hive-3.1.3/apache-hive-3.1.3-bin.tar.gz && \
    tar -xzf apache-hive-3.1.3-bin.tar.gz && \
    mv apache-hive-3.1.3-bin hive-3.1.3 && \
    rm apache-hive-3.1.3-bin.tar.gz

# 设置环境变量
ENV HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
ENV HBASE_HOME=/opt/bigdata/hbase-2.5.5
ENV HIVE_HOME=/opt/bigdata/hive-3.1.3
ENV PATH=$HADOOP_HOME/bin:$HBASE_HOME/bin:$HIVE_HOME/bin:$PATH

# 暴露端口
EXPOSE 9000 9870 16010 10000

CMD ["/bin/bash"]
```

### 构建和运行

```bash
# 构建镜像
docker build -t hadoop-bigdata:latest .

# 运行容器
docker run -it -p 9870:9870 -p 16010:16010 hadoop-bigdata:latest

# 在容器内验证
hadoop version
hbase version
hive --version
```

---

## 方案3: 使用 Kubernetes（高级）

如果您有 Kubernetes 集群，可以使用 Helm 部署：

```bash
# 添加 Helm 仓库
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

# 安装 Hadoop
helm install hadoop bitnami/hadoop

# 安装 HBase
helm install hbase bitnami/hbase

# 安装 Hive
helm install hive bitnami/hive
```

---

## 常见问题

### Q: Docker 容器内无法访问 Windows 文件

**解决方案：**
```bash
# 在 docker-compose.yml 中添加卷挂载
volumes:
  - /mnt/c/Users/32517/Desktop/150:/workspace
```

### Q: 容器内网络连接问题

**解决方案：**
```bash
# 使用 host 网络模式
docker run --network host ...

# 或在 docker-compose.yml 中
network_mode: "host"
```

### Q: 容器内存不足

**解决方案：**
```bash
# 增加 Docker 内存限制
# Docker Desktop 设置 → Resources → Memory: 4GB+

# 或在 docker-compose.yml 中限制
services:
  namenode:
    mem_limit: 2g
```

---

## 优势对比

| 方案 | 优势 | 劣势 |
|------|------|------|
| WSL 原生安装 | 性能最好，完全控制 | 安装复杂，耗时长 |
| Docker 单容器 | 快速部署，易于管理 | 性能略低，资源占用多 |
| Docker Compose | 多服务编排，易于扩展 | 配置复杂 |
| Kubernetes | 生产级别，高可用 | 学习曲线陡，资源占用大 |

---

## 推荐方案

- **学习和测试**: Docker Compose（快速、简单）
- **生产环境**: WSL 原生安装（性能最好）
- **云环境**: Kubernetes（可扩展）

---

## 下一步

选择合适的方案后，运行项目脚本：

```bash
cd scripts
./hdfs_setup.sh
./run_mapreduce.sh
./hbase_setup.sh
./run_hive.sh
```

详见 `运行指南.md`

