#!/usr/bin/env python3

import subprocess
import time

# 使用 hbase shell 命令创建表
commands = """
disable 'customer_orders'
drop 'customer_orders'
create 'customer_orders', {NAME => 'order_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'}, {NAME => 'dish_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'}, {NAME => 'user_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'}
describe 'customer_orders'
list
exit
"""

# 写入临时文件
with open('/tmp/hbase_commands.txt', 'w') as f:
    f.write(commands)

# 执行 hbase shell
try:
    result = subprocess.run(
        ['/opt/bigdata/hbase-2.4.13/bin/hbase', 'shell'],
        input=commands.encode(),
        capture_output=True,
        timeout=30
    )
    print(result.stdout.decode())
    if result.stderr:
        print("STDERR:", result.stderr.decode())
except subprocess.TimeoutExpired:
    print("命令超时")
except Exception as e:
    print(f"错误: {e}")

