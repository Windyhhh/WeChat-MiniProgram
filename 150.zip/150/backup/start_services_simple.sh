#!/bin/bash

# 简化的启动脚本

export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
export ZOOKEEPER_HOME=/opt/bigdata/zookeeper-3.8.5
export HBASE_HOME=/opt/bigdata/hbase-2.4.13
export HIVE_HOME=/opt/bigdata/apache-hive-3.1.2-bin

export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$ZOOKEEPER_HOME/bin:$HBASE_HOME/bin:$HIVE_HOME/bin:$PATH

export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export HDFS_NAMENODE_USER=root
export HDFS_DATANODE_USER=root
export HDFS_SECONDARYNAMENODE_USER=root
export YARN_RESOURCEMANAGER_USER=root
export YARN_NODEMANAGER_USER=root

echo "=========================================="
echo "启动大数据生态系统"
echo "=========================================="
echo ""

# 1. 清理和创建目录
echo "1️⃣ 清理和创建必要的目录..."
rm -rf /tmp/hadoop /tmp/zookeeper
mkdir -p /tmp/hadoop/namenode
mkdir -p /tmp/hadoop/datanode
mkdir -p /tmp/zookeeper
echo "✓ 目录已创建"
echo ""

# 2. 格式化 HDFS
echo "2️⃣ 格式化 HDFS..."
$HADOOP_HOME/bin/hdfs namenode -format -force > /dev/null 2>&1
echo "✓ HDFS 已格式化"
echo ""

# 3. 启动 ZooKeeper
echo "3️⃣ 启动 ZooKeeper..."
$ZOOKEEPER_HOME/bin/zkServer.sh start > /dev/null 2>&1
sleep 2
echo "✓ ZooKeeper 已启动"
echo ""

# 4. 启动 HDFS
echo "4️⃣ 启动 HDFS..."
$HADOOP_HOME/sbin/start-dfs.sh > /dev/null 2>&1
sleep 5
echo "✓ HDFS 已启动"
echo ""

# 5. 启动 YARN
echo "5️⃣ 启动 YARN..."
$HADOOP_HOME/sbin/start-yarn.sh > /dev/null 2>&1
sleep 3
echo "✓ YARN 已启动"
echo ""

# 6. 启动 HBase
echo "6️⃣ 启动 HBase..."
$HBASE_HOME/bin/start-hbase.sh > /dev/null 2>&1
sleep 3
echo "✓ HBase 已启动"
echo ""

echo "=========================================="
echo "✅ 所有服务已启动！"
echo "=========================================="

