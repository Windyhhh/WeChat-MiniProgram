#!/usr/bin/env ruby

# HBase 表创建脚本

begin
  # 尝试删除已存在的表
  disable 'customer_orders'
  drop 'customer_orders'
  puts "✓ 旧表已删除"
rescue
  puts "✓ 表不存在，跳过删除"
end

# 创建表
create 'customer_orders',
  {NAME => 'order_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'},
  {NAME => 'dish_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'},
  {NAME => 'user_info', VERSIONS => 1, TTL => 2592000, COMPRESSION => 'SNAPPY'}

puts "✓ customer_orders 表已创建"

# 查看表结构
describe 'customer_orders'

# 列出所有表
list

