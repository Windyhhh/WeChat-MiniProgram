#!/bin/bash

# ========================================
# 快速安装脚本 - 分步骤执行
# ========================================

set -e

INSTALL_DIR="/opt/bigdata"
HADOOP_VERSION="3.3.6"
HBASE_VERSION="2.5.5"
HIVE_VERSION="3.1.3"
ZOOKEEPER_VERSION="3.9.1"

echo "=========================================="
echo "Hadoop 大数据环境快速安装"
echo "=========================================="
echo ""
echo "安装位置: $INSTALL_DIR"
echo "Hadoop 版本: $HADOOP_VERSION"
echo "HBase 版本: $HBASE_VERSION"
echo "Hive 版本: $HIVE_VERSION"
echo "ZooKeeper 版本: $ZOOKEEPER_VERSION"
echo ""

# ========================================
# 步骤1: 系统更新和基础工具
# ========================================
echo "步骤1: 更新系统..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
    wget curl git vim net-tools \
    openssh-server openssh-client ssh rsync

echo "✓ 基础工具安装完成"

# ========================================
# 步骤2: 安装 Java
# ========================================
echo ""
echo "步骤2: 安装 Java..."

if ! command -v java &> /dev/null; then
    sudo apt-get install -y -qq openjdk-8-jdk
    echo "✓ Java 安装完成"
else
    echo "✓ Java 已安装"
fi

# ========================================
# 步骤3: 创建目录
# ========================================
echo ""
echo "步骤3: 创建安装目录..."

sudo mkdir -p $INSTALL_DIR
sudo chown -R $USER:$USER $INSTALL_DIR
mkdir -p /tmp/hadoop /tmp/zookeeper

echo "✓ 目录创建完成"

# ========================================
# 步骤4: 配置 SSH
# ========================================
echo ""
echo "步骤4: 配置 SSH..."

if [ ! -f ~/.ssh/id_rsa ]; then
    ssh-keygen -t rsa -P "" -f ~/.ssh/id_rsa
    cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
fi

sudo service ssh start 2>/dev/null || true

echo "✓ SSH 配置完成"

# ========================================
# 步骤5: 下载和安装组件
# ========================================
echo ""
echo "步骤5: 下载和安装组件..."
echo "（这可能需要几分钟，取决于网络速度）"

cd $INSTALL_DIR

# Hadoop
if [ ! -d "hadoop-${HADOOP_VERSION}" ]; then
    echo "  下载 Hadoop..."
    wget -q https://archive.apache.org/dist/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz
    tar -xzf hadoop-${HADOOP_VERSION}.tar.gz
    rm hadoop-${HADOOP_VERSION}.tar.gz
fi

# ZooKeeper
if [ ! -d "zookeeper-${ZOOKEEPER_VERSION}" ]; then
    echo "  下载 ZooKeeper..."
    wget -q https://archive.apache.org/dist/zookeeper/zookeeper-${ZOOKEEPER_VERSION}/apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
    tar -xzf apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
    mv apache-zookeeper-${ZOOKEEPER_VERSION}-bin zookeeper-${ZOOKEEPER_VERSION}
    rm apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
fi

# HBase
if [ ! -d "hbase-${HBASE_VERSION}" ]; then
    echo "  下载 HBase..."
    wget -q https://archive.apache.org/dist/hbase/${HBASE_VERSION}/hbase-${HBASE_VERSION}-bin.tar.gz
    tar -xzf hbase-${HBASE_VERSION}-bin.tar.gz
    rm hbase-${HBASE_VERSION}-bin.tar.gz
fi

# Hive
if [ ! -d "hive-${HIVE_VERSION}" ]; then
    echo "  下载 Hive..."
    wget -q https://archive.apache.org/dist/hive/hive-${HIVE_VERSION}/apache-hive-${HIVE_VERSION}-bin.tar.gz
    tar -xzf apache-hive-${HIVE_VERSION}-bin.tar.gz
    mv apache-hive-${HIVE_VERSION}-bin hive-${HIVE_VERSION}
    rm apache-hive-${HIVE_VERSION}-bin.tar.gz
fi

echo "✓ 所有组件下载完成"

# ========================================
# 步骤6: 配置环境变量
# ========================================
echo ""
echo "步骤6: 配置环境变量..."

cat > ~/.bashrc_bigdata << 'EOF'
export HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export YARN_HOME=$HADOOP_HOME
export PATH=$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH

export ZOOKEEPER_HOME=/opt/bigdata/zookeeper-3.9.1
export PATH=$ZOOKEEPER_HOME/bin:$PATH

export HBASE_HOME=/opt/bigdata/hbase-2.5.5
export HBASE_MANAGES_ZK=false
export PATH=$HBASE_HOME/bin:$PATH

export HIVE_HOME=/opt/bigdata/hive-3.1.3
export PATH=$HIVE_HOME/bin:$PATH

export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
EOF

if ! grep -q "bashrc_bigdata" ~/.bashrc; then
    echo "source ~/.bashrc_bigdata" >> ~/.bashrc
fi

source ~/.bashrc_bigdata

echo "✓ 环境变量配置完成"

# ========================================
# 步骤7: 验证安装
# ========================================
echo ""
echo "步骤7: 验证安装..."
echo ""

echo "Java 版本:"
java -version 2>&1 | head -1

echo ""
echo "Hadoop 版本:"
hadoop version 2>&1 | head -1

echo ""
echo "HBase 版本:"
hbase version 2>&1 | head -1

echo ""
echo "Hive 版本:"
hive --version 2>&1 | head -1

echo ""
echo "=========================================="
echo "✓ 安装完成！"
echo "=========================================="
echo ""
echo "下一步:"
echo "1. 运行配置脚本: ./configure_hadoop.sh"
echo "2. 启动服务: ./start_services.sh"
echo "3. 验证服务: ./verify_services.sh"

