#!/bin/bash

# 配置 sudoers，让 windy 用户免密执行 sudo 命令

echo "=========================================="
echo "配置 sudoers 文件"
echo "=========================================="
echo ""

# 检查是否已经配置
if sudo grep -q "windy ALL=(ALL) NOPASSWD: ALL" /etc/sudoers 2>/dev/null; then
    echo "✓ sudoers 已配置，windy 用户已有免密 sudo 权限"
    exit 0
fi

# 使用 visudo 编辑 sudoers（安全方式）
echo "请在编辑器中添加以下行到文件末尾："
echo ""
echo "windy ALL=(ALL) NOPASSWD: ALL"
echo ""
echo "然后保存并退出编辑器"
echo ""

# 调用 visudo
sudo visudo

# 验证配置
echo ""
echo "验证配置..."
if sudo grep -q "windy ALL=(ALL) NOPASSWD: ALL" /etc/sudoers; then
    echo "✓ sudoers 配置成功！"
    echo ""
    echo "现在可以无需密码执行 sudo 命令"
else
    echo "✗ sudoers 配置失败，请检查"
    exit 1
fi

