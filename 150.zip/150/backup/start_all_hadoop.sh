#!/bin/bash

# 启动所有 Hadoop 服务

source ~/.bashrc_bigdata

echo "=========================================="
echo "启动 Hadoop 集群"
echo "=========================================="
echo ""

# 1. 启动 HDFS
echo "1️⃣ 启动 HDFS..."
$HADOOP_HOME/sbin/start-dfs.sh > /dev/null 2>&1
sleep 5
echo "✓ HDFS 已启动"
echo ""

# 2. 启动 YARN
echo "2️⃣ 启动 YARN..."
$HADOOP_HOME/sbin/start-yarn.sh > /dev/null 2>&1
sleep 3
echo "✓ YARN 已启动"
echo ""

# 3. 检查服务状态
echo "3️⃣ 检查服务状态..."
jps
echo ""

echo "=========================================="
echo "✅ Hadoop 集群已启动！"
echo "=========================================="
echo ""
echo "📊 Web 界面："
echo "  • NameNode: http://localhost:9870"
echo "  • ResourceManager: http://localhost:8088"

