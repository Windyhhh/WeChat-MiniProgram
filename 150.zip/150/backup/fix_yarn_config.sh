#!/bin/bash

# 修复 yarn-site.xml 的 aux-services 配置

cat > /tmp/yarn-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>yarn.resourcemanager.hostname</name>
        <value>localhost</value>
    </property>
    <property>
        <name>yarn.nodemanager.aux-services</name>
        <value>mapreduce_shuffle</value>
    </property>
    <property>
        <name>yarn.nodemanager.aux-services.mapreduce_shuffle.class</name>
        <value>org.apache.hadoop.mapred.ShuffleHandler</value>
    </property>
    <property>
        <name>yarn.resourcemanager.address</name>
        <value>localhost:8032</value>
    </property>
</configuration>
EOF

sudo cp /tmp/yarn-site.xml /opt/bigdata/hadoop-3.3.6/etc/hadoop/yarn-site.xml

echo "✓ yarn-site.xml 已修复"
cat /opt/bigdata/hadoop-3.3.6/etc/hadoop/yarn-site.xml

