# 大数据环境安装完成 ✅

## 安装摘要

已成功在 WSL Ubuntu 环境中安装并配置了完整的 Hadoop 生态系统。

### 已安装的组件

| 组件 | 版本 | 位置 | 状态 |
|------|------|------|------|
| Java | OpenJDK 17.0.17 | /usr/lib/jvm/java-17-openjdk-amd64 | ✅ |
| Hadoop | 3.3.6 | /opt/bigdata/hadoop-3.3.6 | ✅ |
| ZooKeeper | 3.8.5 | /opt/bigdata/zookeeper-3.8.5 | ✅ |
| HBase | 2.4.13 | /opt/bigdata/hbase-2.4.13 | ✅ |
| Hive | 3.1.2 | /opt/bigdata/apache-hive-3.1.2-bin | ✅ |
| MySQL JDBC | 8.0.8 | /opt/bigdata/apache-hive-3.1.2-bin/lib | ✅ |

## 快速启动

### 方式 1：使用启动脚本（推荐）

```bash
bash /mnt/c/Users/32517/Desktop/150/start_bigdata_services.sh
```

### 方式 2：手动启动各服务

```bash
# 加载环境变量
source ~/.bashrc_bigdata

# 启动 ZooKeeper
$ZOOKEEPER_HOME/bin/zkServer.sh start

# 启动 HDFS
echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-dfs.sh

# 启动 YARN
echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-yarn.sh

# 启动 HBase
$HBASE_HOME/bin/start-hbase.sh
```

## 服务访问地址

- **NameNode Web UI**: http://localhost:9870
- **ResourceManager Web UI**: http://localhost:8088
- **HBase Master Web UI**: http://localhost:16010

## 验证服务状态

```bash
# 检查 HDFS 状态
hdfs dfsadmin -report

# 检查 YARN 节点
yarn node -list

# 进入 HBase Shell
hbase shell
```

## 环境变量配置

所有环境变量已配置在 `~/.bashrc_bigdata` 中，包括：

- JAVA_HOME
- HADOOP_HOME
- ZOOKEEPER_HOME
- HBASE_HOME
- HIVE_HOME
- PATH 配置

## 关键配置文件

- Hadoop: `/opt/bigdata/hadoop-3.3.6/etc/hadoop/`
  - core-site.xml
  - hdfs-site.xml
  - mapred-site.xml
  - yarn-site.xml
  - hadoop-env.sh

- ZooKeeper: `/opt/bigdata/zookeeper-3.8.5/conf/zoo.cfg`
- HBase: `/opt/bigdata/hbase-2.4.13/conf/hbase-site.xml`

## 常见问题

### 1. 需要 sudo 密码
密码是: `123456`

### 2. 重启后服务不运行
需要重新创建 `/tmp/hadoop` 和 `/tmp/zookeeper` 目录，然后重新启动服务。

### 3. HDFS 无法启动
检查 `/tmp/hadoop/namenode` 目录是否存在，如果不存在需要重新格式化：
```bash
echo '123456' | sudo -S /opt/bigdata/hadoop-3.3.6/bin/hdfs namenode -format -force
```

## 下一步

现在可以：
1. 上传测试数据到 HDFS
2. 运行 MapReduce 任务
3. 在 HBase 中创建表
4. 使用 Hive 进行数据分析

祝您使用愉快！🎉

