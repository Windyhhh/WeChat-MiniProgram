#!/bin/bash

# ========================================
# Hadoop、HBase、Hive 完整安装脚本
# 适用于 Ubuntu/WSL 环境
# ========================================

set -e

echo "=========================================="
echo "开始安装 Hadoop 大数据环境"
echo "=========================================="

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 安装目录
INSTALL_DIR="/opt/bigdata"
HADOOP_VERSION="3.3.6"
HBASE_VERSION="2.5.5"
HIVE_VERSION="3.1.3"
ZOOKEEPER_VERSION="3.9.1"

# ========================================
# 步骤1: 更新系统和安装基础工具
# ========================================
echo -e "${YELLOW}步骤1: 更新系统和安装基础工具...${NC}"
sudo apt-get update
sudo apt-get install -y \
    wget \
    curl \
    git \
    vim \
    net-tools \
    openssh-server \
    openssh-client \
    ssh \
    rsync

echo -e "${GREEN}✓ 基础工具安装完成${NC}"

# ========================================
# 步骤2: 安装 Java
# ========================================
echo -e "${YELLOW}步骤2: 安装 Java...${NC}"

# 检查是否已安装Java
if command -v java &> /dev/null; then
    echo -e "${GREEN}✓ Java 已安装${NC}"
    java -version
else
    sudo apt-get install -y openjdk-8-jdk
    echo -e "${GREEN}✓ Java 安装完成${NC}"
fi

# ========================================
# 步骤3: 创建安装目录和用户
# ========================================
echo -e "${YELLOW}步骤3: 创建安装目录和用户...${NC}"

sudo mkdir -p $INSTALL_DIR
sudo chown -R $USER:$USER $INSTALL_DIR

# 创建hadoop用户（可选）
if ! id "hadoop" &>/dev/null; then
    sudo useradd -m -s /bin/bash hadoop
    echo -e "${GREEN}✓ hadoop 用户创建完成${NC}"
else
    echo -e "${GREEN}✓ hadoop 用户已存在${NC}"
fi

# ========================================
# 步骤4: 配置SSH（Hadoop需要）
# ========================================
echo -e "${YELLOW}步骤4: 配置 SSH...${NC}"

# 生成SSH密钥
if [ ! -f ~/.ssh/id_rsa ]; then
    ssh-keygen -t rsa -P "" -f ~/.ssh/id_rsa
    cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
    echo -e "${GREEN}✓ SSH 密钥生成完成${NC}"
else
    echo -e "${GREEN}✓ SSH 密钥已存在${NC}"
fi

# 启动SSH服务
sudo service ssh start 2>/dev/null || true

# ========================================
# 步骤5: 下载和安装 Hadoop
# ========================================
echo -e "${YELLOW}步骤5: 下载和安装 Hadoop ${HADOOP_VERSION}...${NC}"

cd $INSTALL_DIR

if [ ! -d "hadoop-${HADOOP_VERSION}" ]; then
    echo "下载 Hadoop..."
    wget -q https://archive.apache.org/dist/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz
    tar -xzf hadoop-${HADOOP_VERSION}.tar.gz
    rm hadoop-${HADOOP_VERSION}.tar.gz
    echo -e "${GREEN}✓ Hadoop 下载和解压完成${NC}"
else
    echo -e "${GREEN}✓ Hadoop 已存在${NC}"
fi

# ========================================
# 步骤6: 下载和安装 ZooKeeper
# ========================================
echo -e "${YELLOW}步骤6: 下载和安装 ZooKeeper ${ZOOKEEPER_VERSION}...${NC}"

if [ ! -d "zookeeper-${ZOOKEEPER_VERSION}" ]; then
    echo "下载 ZooKeeper..."
    wget -q https://archive.apache.org/dist/zookeeper/zookeeper-${ZOOKEEPER_VERSION}/apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
    tar -xzf apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
    mv apache-zookeeper-${ZOOKEEPER_VERSION}-bin zookeeper-${ZOOKEEPER_VERSION}
    rm apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
    echo -e "${GREEN}✓ ZooKeeper 下载和解压完成${NC}"
else
    echo -e "${GREEN}✓ ZooKeeper 已存在${NC}"
fi

# ========================================
# 步骤7: 下载和安装 HBase
# ========================================
echo -e "${YELLOW}步骤7: 下载和安装 HBase ${HBASE_VERSION}...${NC}"

if [ ! -d "hbase-${HBASE_VERSION}" ]; then
    echo "下载 HBase..."
    wget -q https://archive.apache.org/dist/hbase/${HBASE_VERSION}/hbase-${HBASE_VERSION}-bin.tar.gz
    tar -xzf hbase-${HBASE_VERSION}-bin.tar.gz
    rm hbase-${HBASE_VERSION}-bin.tar.gz
    echo -e "${GREEN}✓ HBase 下载和解压完成${NC}"
else
    echo -e "${GREEN}✓ HBase 已存在${NC}"
fi

# ========================================
# 步骤8: 下载和安装 Hive
# ========================================
echo -e "${YELLOW}步骤8: 下载和安装 Hive ${HIVE_VERSION}...${NC}"

if [ ! -d "hive-${HIVE_VERSION}" ]; then
    echo "下载 Hive..."
    wget -q https://archive.apache.org/dist/hive/hive-${HIVE_VERSION}/apache-hive-${HIVE_VERSION}-bin.tar.gz
    tar -xzf apache-hive-${HIVE_VERSION}-bin.tar.gz
    mv apache-hive-${HIVE_VERSION}-bin hive-${HIVE_VERSION}
    rm apache-hive-${HIVE_VERSION}-bin.tar.gz
    echo -e "${GREEN}✓ Hive 下载和解压完成${NC}"
else
    echo -e "${GREEN}✓ Hive 已存在${NC}"
fi

# ========================================
# 步骤9: 配置环境变量
# ========================================
echo -e "${YELLOW}步骤9: 配置环境变量...${NC}"

# 创建环境变量配置文件
cat > ~/.bashrc_bigdata << 'EOF'
# Hadoop Environment Variables
export HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export YARN_HOME=$HADOOP_HOME
export PATH=$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH

# ZooKeeper Environment Variables
export ZOOKEEPER_HOME=/opt/bigdata/zookeeper-3.9.1
export PATH=$ZOOKEEPER_HOME/bin:$PATH

# HBase Environment Variables
export HBASE_HOME=/opt/bigdata/hbase-2.5.5
export HBASE_MANAGES_ZK=false
export PATH=$HBASE_HOME/bin:$PATH

# Hive Environment Variables
export HIVE_HOME=/opt/bigdata/hive-3.1.3
export PATH=$HIVE_HOME/bin:$PATH

# Java Environment Variables
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
EOF

# 添加到 .bashrc
if ! grep -q "bashrc_bigdata" ~/.bashrc; then
    echo "source ~/.bashrc_bigdata" >> ~/.bashrc
fi

source ~/.bashrc_bigdata

echo -e "${GREEN}✓ 环境变量配置完成${NC}"

# ========================================
# 步骤10: 验证安装
# ========================================
echo -e "${YELLOW}步骤10: 验证安装...${NC}"

echo ""
echo "Java 版本:"
java -version

echo ""
echo "Hadoop 版本:"
hadoop version | head -1

echo ""
echo "HBase 版本:"
hbase version | head -1

echo ""
echo "Hive 版本:"
hive --version | head -1

echo ""
echo "ZooKeeper 版本:"
zkServer.sh version 2>/dev/null | head -1 || echo "ZooKeeper 已安装"

echo ""
echo -e "${GREEN}=========================================="
echo "✓ 所有组件安装完成！"
echo "==========================================${NC}"

echo ""
echo "下一步操作："
echo "1. 配置 Hadoop: 运行 configure_hadoop.sh"
echo "2. 启动服务: 运行 start_services.sh"
echo "3. 验证服务: 运行 verify_services.sh"

