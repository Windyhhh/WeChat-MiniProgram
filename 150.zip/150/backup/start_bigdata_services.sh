#!/bin/bash

# 启动所有大数据服务的完整脚本

source ~/.bashrc_bigdata

echo "=========================================="
echo "启动大数据生态系统"
echo "=========================================="
echo ""

# 1. 重新创建必要的目录
echo "1️⃣ 创建必要的目录..."
mkdir -p /tmp/hadoop/namenode
mkdir -p /tmp/hadoop/datanode
mkdir -p /tmp/zookeeper
echo "✓ 目录已创建"
echo ""

# 2. 启动 ZooKeeper
echo "2️⃣ 启动 ZooKeeper..."
$ZOOKEEPER_HOME/bin/zkServer.sh start
sleep 2
echo "✓ ZooKeeper 已启动"
echo ""

# 3. 启动 Hadoop HDFS
echo "3️⃣ 启动 Hadoop HDFS..."
echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-dfs.sh > /dev/null 2>&1
sleep 5
echo "✓ HDFS 已启动"
echo ""

# 4. 启动 Hadoop YARN
echo "4️⃣ 启动 Hadoop YARN..."
echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-yarn.sh > /dev/null 2>&1
sleep 3
echo "✓ YARN 已启动"
echo ""

# 5. 启动 HBase
echo "5️⃣ 启动 HBase..."
$HBASE_HOME/bin/start-hbase.sh > /dev/null 2>&1
sleep 3
echo "✓ HBase 已启动"
echo ""

echo "=========================================="
echo "✅ 所有服务已启动！"
echo "=========================================="
echo ""
echo "📊 服务访问地址："
echo "  • NameNode:        http://localhost:9870"
echo "  • ResourceManager: http://localhost:8088"
echo "  • HBase Master:    http://localhost:16010"
echo ""
echo "🔍 验证服务状态："
echo "  hdfs dfsadmin -report"
echo "  hbase shell"

