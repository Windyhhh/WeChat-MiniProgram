-- Hive 数据分析脚本

-- 1. 创建订单表
CREATE TABLE IF NOT EXISTS orders (
    user_id STRING,
    order_id STRING,
    store_id STRING,
    dish_id STRING,
    order_time STRING,
    amount DOUBLE
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

-- 2. 创建用户表
CREATE TABLE IF NOT EXISTS users (
    user_id STRING,
    age_segment STRING,
    taste_preference STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

-- 3. 创建菜品表
CREATE TABLE IF NOT EXISTS dishes (
    dish_id STRING,
    name STRING,
    category STRING,
    price DOUBLE
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

-- 4. 导入订单数据
LOAD DATA INPATH '/user/windy/output/cleaned/part-r-00000' INTO TABLE orders;

-- 5. 导入用户数据
LOAD DATA INPATH '/user/windy/input/profiles/user_profiles.csv' INTO TABLE users;

-- 6. 导入菜品数据
LOAD DATA INPATH '/user/windy/input/dishes/dishes.csv' INTO TABLE dishes;

-- 7. 销量排行榜：统计销量最高的前10名菜品
SELECT 
    d.dish_id,
    d.name,
    COUNT(*) as sales_count,
    SUM(o.amount) as total_amount
FROM orders o
JOIN dishes d ON o.dish_id = d.dish_id
GROUP BY d.dish_id, d.name
ORDER BY sales_count DESC
LIMIT 10;

-- 8. VIP客户发现：找出消费总金额最高的前100名顾客
SELECT 
    u.user_id,
    u.age_segment,
    u.taste_preference,
    COUNT(DISTINCT o.order_id) as order_count,
    SUM(o.amount) as total_spending
FROM orders o
JOIN users u ON o.user_id = u.user_id
GROUP BY u.user_id, u.age_segment, u.taste_preference
ORDER BY total_spending DESC
LIMIT 100;

-- 9. 菜品关联分析：购买"D001"的订单中同时购买其他菜品的比例
SELECT 
    d2.dish_id,
    d2.name,
    COUNT(*) as co_purchase_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(DISTINCT order_id) FROM orders WHERE dish_id = 'D001'), 2) as percentage
FROM orders o1
JOIN orders o2 ON o1.order_id = o2.order_id AND o1.dish_id != o2.dish_id
JOIN dishes d2 ON o2.dish_id = d2.dish_id
WHERE o1.dish_id = 'D001'
GROUP BY d2.dish_id, d2.name
ORDER BY co_purchase_count DESC;

-- 10. 自定义分析：各门店营业额对比
SELECT 
    o.store_id,
    COUNT(DISTINCT o.order_id) as order_count,
    COUNT(*) as item_count,
    SUM(o.amount) as total_revenue,
    ROUND(AVG(o.amount), 2) as avg_amount
FROM orders o
GROUP BY o.store_id
ORDER BY total_revenue DESC;

-- 11. 自定义分析：每日销售趋势
SELECT 
    SUBSTR(o.order_time, 1, 10) as order_date,
    COUNT(DISTINCT o.order_id) as order_count,
    SUM(o.amount) as daily_revenue
FROM orders o
GROUP BY SUBSTR(o.order_time, 1, 10)
ORDER BY order_date;

