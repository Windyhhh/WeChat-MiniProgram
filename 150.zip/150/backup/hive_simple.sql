-- 简化的 Hive 分析脚本

-- 1. 创建外部订单表（指向 MapReduce 输出）
DROP TABLE IF EXISTS orders;
CREATE EXTERNAL TABLE orders (
    user_id STRING,
    order_id STRING,
    store_id STRING,
    dish_id STRING,
    order_time STRING,
    amount DOUBLE
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/windy/output/cleaned';

-- 3. 验证数据
SELECT COUNT(*) as total_orders FROM orders;

-- 4. 销量排行榜：统计销量最高的前10名菜品
SELECT 
    dish_id,
    COUNT(*) as sales_count,
    SUM(amount) as total_amount
FROM orders
GROUP BY dish_id
ORDER BY sales_count DESC
LIMIT 10;

-- 5. VIP客户发现：找出消费总金额最高的前10名顾客
SELECT 
    user_id,
    COUNT(DISTINCT order_id) as order_count,
    SUM(amount) as total_spending
FROM orders
GROUP BY user_id
ORDER BY total_spending DESC
LIMIT 10;

-- 6. 各门店营业额对比
SELECT 
    store_id,
    COUNT(DISTINCT order_id) as order_count,
    SUM(amount) as total_revenue
FROM orders
GROUP BY store_id
ORDER BY total_revenue DESC;

-- 7. 每日销售趋势
SELECT 
    SUBSTR(order_time, 1, 10) as order_date,
    COUNT(DISTINCT order_id) as order_count,
    SUM(amount) as daily_revenue
FROM orders
GROUP BY SUBSTR(order_time, 1, 10)
ORDER BY order_date;

