#!/bin/bash

# ========================================
# 使用国内镜像安装 Hadoop 大数据环境
# ========================================

set -e

INSTALL_DIR="/opt/bigdata"
HADOOP_VERSION="3.3.6"
HBASE_VERSION="2.5.5"
HIVE_VERSION="3.1.3"
ZOOKEEPER_VERSION="3.9.1"

# 国内镜像源
# 清华大学镜像
MIRROR_URL="https://mirrors.tuna.tsinghua.edu.cn/apache"

echo "=========================================="
echo "使用国内镜像安装 Hadoop 大数据环境"
echo "=========================================="
echo "镜像源: $MIRROR_URL"
echo ""

# ========================================
# 步骤1: 下载 Hadoop
# ========================================
echo "步骤1: 下载 Hadoop ${HADOOP_VERSION}..."
cd $INSTALL_DIR

if [ ! -f "hadoop-${HADOOP_VERSION}.tar.gz" ]; then
    echo "从镜像下载..."
    wget -c "${MIRROR_URL}/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz"
    echo "✓ Hadoop 下载完成"
else
    echo "✓ Hadoop 已存在"
fi

echo "解压 Hadoop..."
tar -xzf hadoop-${HADOOP_VERSION}.tar.gz
rm -f hadoop-${HADOOP_VERSION}.tar.gz
echo "✓ Hadoop 解压完成"

# ========================================
# 步骤2: 下载 ZooKeeper
# ========================================
echo ""
echo "步骤2: 下载 ZooKeeper ${ZOOKEEPER_VERSION}..."

if [ ! -f "apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz" ]; then
    echo "从镜像下载..."
    wget -c "${MIRROR_URL}/zookeeper/zookeeper-${ZOOKEEPER_VERSION}/apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz"
    echo "✓ ZooKeeper 下载完成"
else
    echo "✓ ZooKeeper 已存在"
fi

echo "解压 ZooKeeper..."
tar -xzf apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
mv apache-zookeeper-${ZOOKEEPER_VERSION}-bin zookeeper-${ZOOKEEPER_VERSION}
rm -f apache-zookeeper-${ZOOKEEPER_VERSION}-bin.tar.gz
echo "✓ ZooKeeper 解压完成"

# ========================================
# 步骤3: 下载 HBase
# ========================================
echo ""
echo "步骤3: 下载 HBase ${HBASE_VERSION}..."

if [ ! -f "hbase-${HBASE_VERSION}-bin.tar.gz" ]; then
    echo "从镜像下载..."
    wget -c "${MIRROR_URL}/hbase/${HBASE_VERSION}/hbase-${HBASE_VERSION}-bin.tar.gz"
    echo "✓ HBase 下载完成"
else
    echo "✓ HBase 已存在"
fi

echo "解压 HBase..."
tar -xzf hbase-${HBASE_VERSION}-bin.tar.gz
rm -f hbase-${HBASE_VERSION}-bin.tar.gz
echo "✓ HBase 解压完成"

# ========================================
# 步骤4: 下载 Hive
# ========================================
echo ""
echo "步骤4: 下载 Hive ${HIVE_VERSION}..."

if [ ! -f "apache-hive-${HIVE_VERSION}-bin.tar.gz" ]; then
    echo "从镜像下载..."
    wget -c "${MIRROR_URL}/hive/hive-${HIVE_VERSION}/apache-hive-${HIVE_VERSION}-bin.tar.gz"
    echo "✓ Hive 下载完成"
else
    echo "✓ Hive 已存在"
fi

echo "解压 Hive..."
tar -xzf apache-hive-${HIVE_VERSION}-bin.tar.gz
mv apache-hive-${HIVE_VERSION}-bin hive-${HIVE_VERSION}
rm -f apache-hive-${HIVE_VERSION}-bin.tar.gz
echo "✓ Hive 解压完成"

# ========================================
# 步骤5: 配置环境变量
# ========================================
echo ""
echo "步骤5: 配置环境变量..."

cat > ~/.bashrc_bigdata << 'EOF'
export HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export YARN_HOME=$HADOOP_HOME
export PATH=$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH

export ZOOKEEPER_HOME=/opt/bigdata/zookeeper-3.9.1
export PATH=$ZOOKEEPER_HOME/bin:$PATH

export HBASE_HOME=/opt/bigdata/hbase-2.5.5
export HBASE_MANAGES_ZK=false
export PATH=$HBASE_HOME/bin:$PATH

export HIVE_HOME=/opt/bigdata/hive-3.1.3
export PATH=$HIVE_HOME/bin:$PATH

export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
EOF

if ! grep -q "bashrc_bigdata" ~/.bashrc; then
    echo "source ~/.bashrc_bigdata" >> ~/.bashrc
fi

source ~/.bashrc_bigdata
echo "✓ 环境变量配置完成"

# ========================================
# 步骤6: 验证安装
# ========================================
echo ""
echo "步骤6: 验证安装..."
echo ""

echo "Java 版本:"
java -version 2>&1 | head -1

echo ""
echo "Hadoop 版本:"
hadoop version 2>&1 | head -1

echo ""
echo "HBase 版本:"
hbase version 2>&1 | head -1

echo ""
echo "Hive 版本:"
hive --version 2>&1 | head -1

echo ""
echo "ZooKeeper 版本:"
zkServer.sh version 2>&1 | head -1

echo ""
echo "=========================================="
echo "✓ 安装完成！"
echo "=========================================="
echo ""
echo "下一步:"
echo "1. 运行配置脚本: ./configure_hadoop.sh"
echo "2. 启动服务: ./start_services.sh"
echo "3. 验证服务: ./verify_services.sh"

