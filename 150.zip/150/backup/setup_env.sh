#!/bin/bash

# 设置大数据环境变量

INSTALL_DIR="/opt/bigdata"

echo "=========================================="
echo "配置环境变量"
echo "=========================================="

# 创建环境变量配置文件
cat > ~/.bashrc_bigdata << 'EOF'
# 大数据环境变量配置

export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export HADOOP_HOME=/opt/bigdata/hadoop-3.3.6
export ZOOKEEPER_HOME=/opt/bigdata/zookeeper-3.8.5
export HBASE_HOME=/opt/bigdata/hbase-2.4.13
export HIVE_HOME=/opt/bigdata/apache-hive-3.1.2-bin

# 添加到 PATH
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$ZOOKEEPER_HOME/bin:$HBASE_HOME/bin:$HIVE_HOME/bin:$PATH

# Hadoop 配置
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export HDFS_NAMENODE_USER=root
export HDFS_DATANODE_USER=root
export HDFS_SECONDARYNAMENODE_USER=root
export YARN_RESOURCEMANAGER_USER=root
export YARN_NODEMANAGER_USER=root

# HBase 配置
export HBASE_MANAGES_ZK=false

echo "✓ 大数据环境变量已加载"
EOF

# 将环境变量加入到 ~/.bashrc
if ! grep -q "bashrc_bigdata" ~/.bashrc; then
    echo "" >> ~/.bashrc
    echo "# 加载大数据环境变量" >> ~/.bashrc
    echo "source ~/.bashrc_bigdata" >> ~/.bashrc
    echo "✓ 已添加到 ~/.bashrc"
fi

# 立即加载环境变量
source ~/.bashrc_bigdata

echo ""
echo "=========================================="
echo "✅ 环境变量配置完成！"
echo "=========================================="
echo ""
echo "已配置的环境变量："
echo "  JAVA_HOME=$JAVA_HOME"
echo "  HADOOP_HOME=$HADOOP_HOME"
echo "  ZOOKEEPER_HOME=$ZOOKEEPER_HOME"
echo "  HBASE_HOME=$HBASE_HOME"
echo "  HIVE_HOME=$HIVE_HOME"
echo ""
echo "下一步："
echo "  bash configure_services.sh"

