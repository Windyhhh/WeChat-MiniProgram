#!/bin/bash

# 启动所有大数据服务

source ~/.bashrc_bigdata

echo "=========================================="
echo "启动大数据生态系统服务"
echo "=========================================="
echo ""

# 1. 启动 ZooKeeper
echo "1️⃣ 启动 ZooKeeper..."
mkdir -p /tmp/zookeeper
$ZOOKEEPER_HOME/bin/zkServer.sh start
sleep 2
echo "✓ ZooKeeper 已启动"
echo ""

# 2. 启动 Hadoop HDFS
echo "2️⃣ 启动 Hadoop HDFS..."
sudo -E $HADOOP_HOME/sbin/start-dfs.sh
sleep 3
echo "✓ HDFS 已启动"
echo ""

# 3. 启动 Hadoop YARN
echo "3️⃣ 启动 Hadoop YARN..."
sudo -E $HADOOP_HOME/sbin/start-yarn.sh
sleep 2
echo "✓ YARN 已启动"
echo ""

# 4. 启动 HBase
echo "4️⃣ 启动 HBase..."
$HBASE_HOME/bin/start-hbase.sh
sleep 3
echo "✓ HBase 已启动"
echo ""

echo "=========================================="
echo "✅ 所有服务已启动！"
echo "=========================================="
echo ""
echo "服务访问地址："
echo "  NameNode:      http://localhost:9870"
echo "  ResourceManager: http://localhost:8088"
echo "  HBase Master:  http://localhost:16010"
echo ""
echo "验证服务状态："
echo "  jps"

