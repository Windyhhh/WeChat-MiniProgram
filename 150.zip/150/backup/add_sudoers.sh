#!/bin/bash

# 添加 windy 用户到 sudoers，允许免密 sudo

echo "添加 windy 用户到 sudoers..."

# 检查是否已经存在
if grep -q "windy ALL=(ALL) NOPASSWD: ALL" /etc/sudoers 2>/dev/null; then
    echo "✓ windy 用户已在 sudoers 中"
    exit 0
fi

# 添加到 sudoers
echo "windy ALL=(ALL) NOPASSWD: ALL" | sudo tee -a /etc/sudoers > /dev/null

# 验证
if grep -q "windy ALL=(ALL) NOPASSWD: ALL" /etc/sudoers; then
    echo "✓ sudoers 配置成功！"
    echo "windy 用户现在可以无需密码执行 sudo 命令"
else
    echo "✗ 配置失败"
    exit 1
fi

