import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.io.compress.Compression;

public class CreateHBaseTable {
    public static void main(String[] args) throws Exception {
        Configuration config = HBaseConfiguration.create();
        Connection connection = ConnectionFactory.createConnection(config);
        Admin admin = connection.getAdmin();
        
        TableName tableName = TableName.valueOf("customer_orders");
        
        // 删除已存在的表
        if (admin.tableExists(tableName)) {
            admin.disableTable(tableName);
            admin.deleteTable(tableName);
            System.out.println("✓ 旧表已删除");
        }
        
        // 创建表
        HTableDescriptor tableDesc = new HTableDescriptor(tableName);
        
        // 添加列族
        HColumnDescriptor orderInfo = new HColumnDescriptor("order_info");
        orderInfo.setCompressionType(Compression.Algorithm.SNAPPY);
        orderInfo.setTimeToLive(2592000); // 30天
        tableDesc.addFamily(orderInfo);
        
        HColumnDescriptor dishInfo = new HColumnDescriptor("dish_info");
        dishInfo.setCompressionType(Compression.Algorithm.SNAPPY);
        dishInfo.setTimeToLive(2592000);
        tableDesc.addFamily(dishInfo);
        
        HColumnDescriptor userInfo = new HColumnDescriptor("user_info");
        userInfo.setCompressionType(Compression.Algorithm.SNAPPY);
        userInfo.setTimeToLive(2592000);
        tableDesc.addFamily(userInfo);
        
        admin.createTable(tableDesc);
        System.out.println("✓ customer_orders 表已创建");
        
        admin.close();
        connection.close();
    }
}

