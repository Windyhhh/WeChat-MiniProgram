#!/bin/bash

# 修复 mapred-site.xml 的配置

cat > /tmp/mapred-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>mapreduce.framework.name</name>
        <value>yarn</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.address</name>
        <value>localhost:10020</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>localhost:19888</value>
    </property>
    <!-- MRAppMaster 环境变量配置 -->
    <property>
        <name>yarn.app.mapreduce.am.env</name>
        <value>HADOOP_MAPRED_HOME=/opt/bigdata/hadoop-3.3.6</value>
    </property>
    <property>
        <name>mapreduce.map.env</name>
        <value>HADOOP_MAPRED_HOME=/opt/bigdata/hadoop-3.3.6</value>
    </property>
    <property>
        <name>mapreduce.reduce.env</name>
        <value>HADOOP_MAPRED_HOME=/opt/bigdata/hadoop-3.3.6</value>
    </property>
    <!-- 内存配置 -->
    <property>
        <name>yarn.app.mapreduce.am.resource.mb</name>
        <value>1024</value>
    </property>
    <property>
        <name>mapreduce.map.memory.mb</name>
        <value>1024</value>
    </property>
    <property>
        <name>mapreduce.reduce.memory.mb</name>
        <value>1024</value>
    </property>
</configuration>
EOF

sudo cp /tmp/mapred-site.xml /opt/bigdata/hadoop-3.3.6/etc/hadoop/mapred-site.xml

echo "✓ mapred-site.xml 已修复"
cat /opt/bigdata/hadoop-3.3.6/etc/hadoop/mapred-site.xml

