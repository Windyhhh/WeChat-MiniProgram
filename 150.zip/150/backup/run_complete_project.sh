#!/bin/bash

# 完整项目运行脚本

source ~/.bashrc_bigdata

PROJECT_DIR="/mnt/c/Users/32517/Desktop/150"
DATA_DIR="$PROJECT_DIR/data"

echo "=========================================="
echo "🚀 开始运行完整项目"
echo "=========================================="
echo ""

# 1. 确保所有服务都在运行
echo "1️⃣ 检查并启动服务..."
mkdir -p /tmp/hadoop/namenode /tmp/hadoop/datanode /tmp/zookeeper

# 检查 ZooKeeper
if ! pgrep -f QuorumPeerMain > /dev/null; then
    echo "  启动 ZooKeeper..."
    $ZOOKEEPER_HOME/bin/zkServer.sh start > /dev/null 2>&1
    sleep 2
fi

# 检查 HDFS
if ! hdfs dfsadmin -report > /dev/null 2>&1; then
    echo "  启动 HDFS..."
    echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-dfs.sh > /dev/null 2>&1
    sleep 5
fi

# 检查 YARN
if ! yarn node -list > /dev/null 2>&1; then
    echo "  启动 YARN..."
    echo '123456' | sudo -S -E $HADOOP_HOME/sbin/start-yarn.sh > /dev/null 2>&1
    sleep 3
fi

# 检查 HBase
if ! echo "status" | hbase shell 2>&1 | grep -q "version"; then
    echo "  启动 HBase..."
    $HBASE_HOME/bin/start-hbase.sh > /dev/null 2>&1
    sleep 3
fi

echo "✓ 所有服务已启动"
echo ""

# 2. 上传数据到 HDFS
echo "2️⃣ 上传数据到 HDFS..."
hdfs dfs -mkdir -p /user/bigdata/input/logs
hdfs dfs -mkdir -p /user/bigdata/input/profiles
hdfs dfs -mkdir -p /user/bigdata/input/dishes

hdfs dfs -put -f $DATA_DIR/order_log_*.txt /user/bigdata/input/logs/
hdfs dfs -put -f $DATA_DIR/user_profiles.csv /user/bigdata/input/profiles/
hdfs dfs -put -f $DATA_DIR/dishes.csv /user/bigdata/input/dishes/

echo "✓ 数据已上传"
echo ""

# 3. 运行 MapReduce 清洗
echo "3️⃣ 运行 MapReduce 数据清洗..."
cd $PROJECT_DIR/mapreduce
mvn clean package -q
hadoop jar target/order-analysis-1.0.jar com.bigdata.OrderCleaner \
    /user/bigdata/input/logs /user/bigdata/output/cleaned 2>&1 | tail -10

echo "✓ MapReduce 清洗完成"
echo ""

# 4. 创建 Hive 表
echo "4️⃣ 创建 Hive 表..."
hive -f $PROJECT_DIR/scripts/hive_setup.sql 2>&1 | tail -20

echo "✓ Hive 表已创建"
echo ""

# 5. 运行 Hive 分析
echo "5️⃣ 运行 Hive 分析..."
echo ""
echo "--- 销量排行榜（前10） ---"
hive -e "SELECT dish_name, COUNT(*) as sales FROM orders GROUP BY dish_name ORDER BY sales DESC LIMIT 10;" 2>&1 | tail -15

echo ""
echo "--- VIP 客户（前10） ---"
hive -e "SELECT user_id, SUM(amount) as total_spend FROM orders GROUP BY user_id ORDER BY total_spend DESC LIMIT 10;" 2>&1 | tail -15

echo ""
echo "=========================================="
echo "✅ 项目运行完成！"
echo "=========================================="
echo ""
echo "📊 Web 界面："
echo "  • NameNode: http://localhost:9870"
echo "  • ResourceManager: http://localhost:8088"
echo "  • HBase Master: http://localhost:16010"

