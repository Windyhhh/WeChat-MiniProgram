#!/bin/bash

# ========================================
# 启动所有大数据服务
# ========================================

set -e

echo "=========================================="
echo "启动大数据服务"
echo "=========================================="

# 加载环境变量
source ~/.bashrc_bigdata

# ========================================
# 1. 启动 ZooKeeper
# ========================================
echo ""
echo "步骤1: 启动 ZooKeeper..."
zkServer.sh start
sleep 2

# ========================================
# 2. 启动 HDFS
# ========================================
echo ""
echo "步骤2: 启动 HDFS..."
start-dfs.sh
sleep 3

# ========================================
# 3. 启动 YARN
# ========================================
echo ""
echo "步骤3: 启动 YARN..."
start-yarn.sh
sleep 3

# ========================================
# 4. 启动 HBase
# ========================================
echo ""
echo "步骤4: 启动 HBase..."
start-hbase.sh
sleep 3

# ========================================
# 5. 启动 Hive Metastore（可选）
# ========================================
echo ""
echo "步骤5: 启动 Hive Metastore..."
nohup hive --service metastore > /tmp/hive_metastore.log 2>&1 &
sleep 2

# ========================================
# 6. 验证服务
# ========================================
echo ""
echo "=========================================="
echo "验证服务状态..."
echo "=========================================="

echo ""
echo "ZooKeeper 状态:"
zkServer.sh status

echo ""
echo "HDFS 状态:"
hdfs dfsadmin -report | head -10

echo ""
echo "YARN 状态:"
yarn node -list

echo ""
echo "HBase 状态:"
hbase shell << EOF
status
exit
EOF

echo ""
echo "=========================================="
echo "✓ 所有服务启动完成！"
echo "=========================================="

echo ""
echo "Web UI 访问地址:"
echo "- HDFS NameNode: http://localhost:9870"
echo "- YARN ResourceManager: http://localhost:8088"
echo "- HBase Master: http://localhost:16010"
echo "- MapReduce JobHistory: http://localhost:19888"

echo ""
echo "下一步: 运行项目脚本"
echo "cd scripts"
echo "./hdfs_setup.sh"