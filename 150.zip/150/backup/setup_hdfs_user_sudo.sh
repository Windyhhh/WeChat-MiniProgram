#!/bin/bash

# 为 windy 用户设置 HDFS 专属目录（使用 sudo 执行）

source ~/.bashrc_bigdata

echo "=========================================="
echo "为 windy 用户设置 HDFS 专属目录"
echo "=========================================="
echo ""

# 1. 创建 windy 用户的根目录（使用 sudo）
echo "1️⃣ 创建 /user/windy 目录..."
sudo -u root /opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy
echo "✓ 目录已创建"
echo ""

# 2. 修改所有者为 windy
echo "2️⃣ 修改目录所有者..."
sudo -u root /opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -chown windy:windy /user/windy
echo "✓ 所有者已修改"
echo ""

# 3. 赋予权限
echo "3️⃣ 赋予目录权限..."
sudo -u root /opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -chmod 755 /user/windy
echo "✓ 权限已设置"
echo ""

# 4. 创建输入目录
echo "4️⃣ 创建输入目录..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/logs
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/profiles
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/dishes
echo "✓ 输入目录已创建"
echo ""

# 5. 复制数据到新目录
echo "5️⃣ 复制数据文件..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/logs/* /user/windy/input/logs/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/profiles/* /user/windy/input/profiles/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/dishes/* /user/windy/input/dishes/
echo "✓ 数据已复制"
echo ""

# 6. 验证
echo "6️⃣ 验证目录结构..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -ls -R /user/windy/
echo ""

echo "=========================================="
echo "✅ HDFS 用户目录设置完成！"
echo "=========================================="

