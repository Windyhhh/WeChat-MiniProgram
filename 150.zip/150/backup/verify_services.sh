#!/bin/bash

# ========================================
# 验证所有服务状态
# ========================================

echo "=========================================="
echo "验证大数据服务状态"
echo "=========================================="

# 加载环境变量
source ~/.bashrc_bigdata

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# ========================================
# 检查 Java
# ========================================
echo ""
echo -e "${YELLOW}1. Java 版本:${NC}"
java -version 2>&1 | head -1

# ========================================
# 检查 Hadoop
# ========================================
echo ""
echo -e "${YELLOW}2. Hadoop 版本:${NC}"
hadoop version | head -1

# ========================================
# 检查 HDFS
# ========================================
echo ""
echo -e "${YELLOW}3. HDFS 状态:${NC}"
if hdfs dfsadmin -report &>/dev/null; then
    echo -e "${GREEN}✓ HDFS 运行中${NC}"
    hdfs dfsadmin -report | head -5
else
    echo -e "${RED}✗ HDFS 未运行${NC}"
fi

# ========================================
# 检查 YARN
# ========================================
echo ""
echo -e "${YELLOW}4. YARN 状态:${NC}"
if yarn node -list &>/dev/null; then
    echo -e "${GREEN}✓ YARN 运行中${NC}"
    yarn node -list
else
    echo -e "${RED}✗ YARN 未运行${NC}"
fi

# ========================================
# 检查 ZooKeeper
# ========================================
echo ""
echo -e "${YELLOW}5. ZooKeeper 状态:${NC}"
if zkServer.sh status &>/dev/null; then
    echo -e "${GREEN}✓ ZooKeeper 运行中${NC}"
    zkServer.sh status
else
    echo -e "${RED}✗ ZooKeeper 未运行${NC}"
fi

# ========================================
# 检查 HBase
# ========================================
echo ""
echo -e "${YELLOW}6. HBase 版本:${NC}"
hbase version | head -1

echo ""
echo -e "${YELLOW}7. HBase 状态:${NC}"
if echo "status" | hbase shell 2>/dev/null | grep -q "version"; then
    echo -e "${GREEN}✓ HBase 运行中${NC}"
else
    echo -e "${RED}✗ HBase 未运行${NC}"
fi

# ========================================
# 检查 Hive
# ========================================
echo ""
echo -e "${YELLOW}8. Hive 版本:${NC}"
hive --version | head -1

# ========================================
# 检查进程
# ========================================
echo ""
echo -e "${YELLOW}9. 运行中的进程:${NC}"
echo "Hadoop 进程:"
jps | grep -E "NameNode|DataNode|ResourceManager|NodeManager" || echo "未找到 Hadoop 进程"

echo ""
echo "HBase 进程:"
jps | grep -E "HMaster|HRegionServer" || echo "未找到 HBase 进程"

echo ""
echo "ZooKeeper 进程:"
jps | grep QuorumPeerMain || echo "未找到 ZooKeeper 进程"

# ========================================
# 检查端口
# ========================================
echo ""
echo -e "${YELLOW}10. 端口检查:${NC}"
echo "HDFS NameNode (9000):"
netstat -tuln 2>/dev/null | grep 9000 || echo "未监听"

echo "HDFS Web UI (9870):"
netstat -tuln 2>/dev/null | grep 9870 || echo "未监听"

echo "YARN ResourceManager (8032):"
netstat -tuln 2>/dev/null | grep 8032 || echo "未监听"

echo "YARN Web UI (8088):"
netstat -tuln 2>/dev/null | grep 8088 || echo "未监听"

echo "HBase Master (16000):"
netstat -tuln 2>/dev/null | grep 16000 || echo "未监听"

echo "HBase Web UI (16010):"
netstat -tuln 2>/dev/null | grep 16010 || echo "未监听"

echo "ZooKeeper (2181):"
netstat -tuln 2>/dev/null | grep 2181 || echo "未监听"

echo ""
echo "=========================================="
echo "✓ 验证完成"
echo "=========================================="

echo ""
echo "Web UI 访问地址:"
echo "- HDFS NameNode: http://localhost:9870"
echo "- YARN ResourceManager: http://localhost:8088"
echo "- HBase Master: http://localhost:16010"
echo "- MapReduce JobHistory: http://localhost:19888"

