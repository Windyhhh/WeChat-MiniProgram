#!/bin/bash

# 大数据生态系统安装脚本 - 官方推荐版本
# Hadoop 3.3.6 + ZooKeeper 3.6.2 + HBase 2.4.13 + Hive 3.1.2

set -e

INSTALL_DIR="/opt/bigdata"
DOWNLOAD_DIR="/tmp/bigdata_downloads"

echo "=========================================="
echo "大数据生态系统安装 - 官方推荐版本"
echo "=========================================="
echo ""
echo "版本信息："
echo "  Hadoop:     3.3.6"
echo "  ZooKeeper:  3.6.2"
echo "  HBase:      2.4.13"
echo "  Hive:       3.1.2"
echo "=========================================="
echo ""

# 创建目录
echo "1️⃣  创建安装目录..."
sudo mkdir -p $INSTALL_DIR
sudo chown -R $(whoami):$(whoami) $INSTALL_DIR
mkdir -p $DOWNLOAD_DIR
cd $DOWNLOAD_DIR

# 下载 Hadoop 3.3.6
echo ""
echo "2️⃣  下载 Hadoop 3.3.6..."
if [ ! -f "hadoop-3.3.6.tar.gz" ]; then
    wget -c https://archive.apache.org/dist/hadoop/common/hadoop-3.3.6/hadoop-3.3.6.tar.gz
    echo "✓ Hadoop 3.3.6 下载完成"
else
    echo "✓ Hadoop 3.3.6 已存在"
fi

# 下载 ZooKeeper 3.6.2
echo ""
echo "3️⃣  下载 ZooKeeper 3.6.2..."
if [ ! -f "apache-zookeeper-3.6.2-bin.tar.gz" ]; then
    wget -c https://archive.apache.org/dist/zookeeper/zookeeper-3.6.2/apache-zookeeper-3.6.2-bin.tar.gz
    echo "✓ ZooKeeper 3.6.2 下载完成"
else
    echo "✓ ZooKeeper 3.6.2 已存在"
fi

# 下载 HBase 2.4.13
echo ""
echo "4️⃣  下载 HBase 2.4.13..."
if [ ! -f "hbase-2.4.13-bin.tar.gz" ]; then
    wget -c https://archive.apache.org/dist/hbase/2.4.13/hbase-2.4.13-bin.tar.gz
    echo "✓ HBase 2.4.13 下载完成"
else
    echo "✓ HBase 2.4.13 已存在"
fi

# 下载 Hive 3.1.2
echo ""
echo "5️⃣  下载 Hive 3.1.2..."
if [ ! -f "apache-hive-3.1.2-bin.tar.gz" ]; then
    wget -c https://archive.apache.org/dist/hive/hive-3.1.2/apache-hive-3.1.2-bin.tar.gz
    echo "✓ Hive 3.1.2 下载完成"
else
    echo "✓ Hive 3.1.2 已存在"
fi

echo ""
echo "=========================================="
echo "✅ 所有文件下载完成！"
echo "=========================================="
echo ""
echo "下一步："
echo "  bash extract_and_setup.sh"

