#!/bin/bash

# 为 windy 用户设置 HDFS 目录结构

source ~/.bashrc_bigdata

echo "=========================================="
echo "为 windy 用户设置 HDFS 目录"
echo "=========================================="
echo ""

# 1. 创建输入目录
echo "1️⃣ 创建输入目录..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/logs
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/profiles
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/input/dishes
echo "✓ 输入目录已创建"
echo ""

# 2. 创建输出目录
echo "2️⃣ 创建输出目录..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -mkdir -p /user/windy/output
echo "✓ 输出目录已创建"
echo ""

# 3. 复制数据文件
echo "3️⃣ 复制数据文件..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/logs/* /user/windy/input/logs/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/profiles/* /user/windy/input/profiles/
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -cp /user/bigdata/input/dishes/* /user/windy/input/dishes/
echo "✓ 数据已复制"
echo ""

# 4. 验证目录结构
echo "4️⃣ 验证目录结构..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -ls -R /user/windy/
echo ""

echo "=========================================="
echo "✅ HDFS 目录设置完成！"
echo "=========================================="

