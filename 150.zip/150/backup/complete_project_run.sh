#!/bin/bash

# 完整项目运行脚本

source ~/.bashrc_bigdata

echo "=========================================="
echo "🚀 完整项目运行"
echo "=========================================="
echo ""

# 1. 启动 HDFS
echo "1️⃣ 启动 HDFS..."
echo "123456" | sudo -S /opt/bigdata/hadoop-3.3.6/sbin/start-dfs.sh > /dev/null 2>&1
sleep 5
echo "✓ HDFS 已启动"
echo ""

# 2. 启动 YARN
echo "2️⃣ 启动 YARN..."
echo "123456" | sudo -S /opt/bigdata/hadoop-3.3.6/sbin/start-yarn.sh > /dev/null 2>&1
sleep 5
echo "✓ YARN 已启动"
echo ""

# 3. 检查服务
echo "3️⃣ 检查服务状态..."
jps
echo ""

# 4. 运行 MapReduce
echo "4️⃣ 运行 MapReduce 清洗任务..."
cd /mnt/c/Users/32517/Desktop/150/mapreduce
HADOOP_USER_NAME=root hadoop jar target/order-data-cleaner-1.0-SNAPSHOT.jar /user/windy/input/logs /user/windy/output/cleaned 2>&1 | tail -50
echo ""

# 5. 验证输出
echo "5️⃣ 验证输出..."
/opt/bigdata/hadoop-3.3.6/bin/hdfs dfs -ls -R /user/windy/output/
echo ""

echo "=========================================="
echo "✅ 项目运行完成！"
echo "=========================================="

