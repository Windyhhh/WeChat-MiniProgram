#!/bin/bash

# ========================================
# Hadoop 配置脚本
# ========================================

set -e

echo "=========================================="
echo "配置 Hadoop"
echo "=========================================="

HADOOP_HOME="/opt/bigdata/hadoop-3.3.6"
HADOOP_CONF_DIR="$HADOOP_HOME/etc/hadoop"
ZOOKEEPER_HOME="/opt/bigdata/zookeeper-3.8.5"
HBASE_HOME="/opt/bigdata/hbase-2.4.13"

# ========================================
# 1. 配置 Hadoop core-site.xml
# ========================================
echo "配置 core-site.xml..."

cat > $HADOOP_CONF_DIR/core-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://localhost:9000</value>
    </property>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>/tmp/hadoop</value>
    </property>
    <property>
        <name>hadoop.proxyuser.root.groups</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.root.hosts</name>
        <value>*</value>
    </property>
</configuration>
EOF

# ========================================
# 2. 配置 Hadoop hdfs-site.xml
# ========================================
echo "配置 hdfs-site.xml..."

cat > $HADOOP_CONF_DIR/hdfs-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/tmp/hadoop/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/tmp/hadoop/datanode</value>
    </property>
    <property>
        <name>dfs.namenode.secondary.http-address</name>
        <value>localhost:9001</value>
    </property>
</configuration>
EOF

# ========================================
# 3. 配置 Hadoop mapred-site.xml
# ========================================
echo "配置 mapred-site.xml..."

cat > $HADOOP_CONF_DIR/mapred-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>mapreduce.framework.name</name>
        <value>yarn</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.address</name>
        <value>localhost:10020</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>localhost:19888</value>
    </property>
</configuration>
EOF

# ========================================
# 4. 配置 Hadoop yarn-site.xml
# ========================================
echo "配置 yarn-site.xml..."

cat > $HADOOP_CONF_DIR/yarn-site.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>yarn.resourcemanager.hostname</name>
        <value>localhost</value>
    </property>
    <property>
        <name>yarn.nodemanager.aux-services</name>
        <value>mapreduce_shuffle</value>
    </property>
    <property>
        <name>yarn.nodemanager.aux-services.mapreduce_shuffle.class</name>
        <value>org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat</value>
    </property>
    <property>
        <name>yarn.resourcemanager.address</name>
        <value>localhost:8032</value>
    </property>
</configuration>
EOF

# ========================================
# 5. 配置 ZooKeeper
# ========================================
echo "配置 ZooKeeper..."

mkdir -p /tmp/zookeeper
cat > $ZOOKEEPER_HOME/conf/zoo.cfg << 'EOF'
tickTime=2000
dataDir=/tmp/zookeeper
clientPort=2181
server.1=localhost:2888:3888
EOF

# ========================================
# 6. 配置 HBase
# ========================================
echo "配置 HBase..."

cat > $HBASE_HOME/conf/hbase-site.xml << 'EOF'
<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>hbase.rootdir</name>
        <value>hdfs://localhost:9000/hbase</value>
    </property>
    <property>
        <name>hbase.cluster.distributed</name>
        <value>false</value>
    </property>
    <property>
        <name>hbase.zookeeper.quorum</name>
        <value>localhost</value>
    </property>
    <property>
        <name>hbase.zookeeper.property.dataDir</name>
        <value>/tmp/zookeeper</value>
    </property>
    <property>
        <name>hbase.unsafe.stream.capability.enforce</name>
        <value>false</value>
    </property>
</configuration>
EOF

cat > $HBASE_HOME/conf/hbase-env.sh << 'EOF'
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export HBASE_MANAGES_ZK=false
EOF

# ========================================
# 7. 创建必要的目录
# ========================================
echo "创建必要的目录..."

mkdir -p /tmp/hadoop/namenode
mkdir -p /tmp/hadoop/datanode
mkdir -p /tmp/zookeeper

# ========================================
# 8. 格式化 HDFS
# ========================================
echo "格式化 HDFS..."

sudo -E $HADOOP_HOME/bin/hdfs namenode -format -force

echo ""
echo "=========================================="
echo "✓ Hadoop 配置完成！"
echo "=========================================="
echo ""
echo "下一步: 运行 start_services.sh 启动服务"

