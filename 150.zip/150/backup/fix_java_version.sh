#!/bin/bash

# 修改 Hadoop 配置文件，使用 Java 8

echo "修改 hadoop-env.sh..."
sudo sed -i 's|java-17-openjdk|java-8-openjdk|g' /opt/bigdata/hadoop-3.3.6/etc/hadoop/hadoop-env.sh

echo "修改 yarn-env.sh..."
sudo sed -i 's|java-17-openjdk|java-8-openjdk|g' /opt/bigdata/hadoop-3.3.6/etc/hadoop/yarn-env.sh

echo "验证修改..."
echo "=== hadoop-env.sh ==="
grep "export JAVA_HOME" /opt/bigdata/hadoop-3.3.6/etc/hadoop/hadoop-env.sh

echo ""
echo "=== yarn-env.sh ==="
grep "export JAVA_HOME" /opt/bigdata/hadoop-3.3.6/etc/hadoop/yarn-env.sh

echo ""
echo "✓ 配置文件已修改"

